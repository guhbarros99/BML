/* Rotinas do programa: Seven +
 *Autor: Gustavo Barros
 *Funcionalidade: FrontEnd
 *Licença: GNU
 * Data: 2024/04/05
 * Versão: v1.0
 * Descrição = das atividades:
 *  1. Função para o menu principal com interatividade com usuario.
 */

 function menuShow(){
   
    let menuMobile = document.querySelector('.mobile-menu');
    let mobileMenuIcon = document.querySelector('.mobile-menu-icon');

    if(menuMobile.classList.contains('open')){
        menuMobile.classList.remove('open');
        mobileMenuIcon.classList.remove('close');
        document.querySelector('.icon').src = 'img/menu_36dp.png';
    }else{
        menuMobile.classList.add('open');
        mobileMenuIcon.classList.add('close');
        document.querySelector('.icon').src = "img/close_36dp.svg";
    }
 }