
function menu(){
    let menu = document.getElementaryByID('.mobile-menu')

    if(menu.style.display == 'block'){
        menu.style.display = 'none';
    }else{
        menu.style.display = "block";
    }
}

const modalBnt = document.querySelector('.modal-bnt');
const modal = document.querySelector('.modal-overlay');
const closeBnt = document.querySelector('.close-bnt');


modalBnt.addEventListener('click',function(){
    modal.classList.add('open-modal');
});
closeBnt.addEventListener('click',function(){
    modal.classList.remove('open-modal');
});