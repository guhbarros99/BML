const button = document.querySelector("enviar")
const modal = document.querySelector("dialog")
const buttonClose = document.querySelector("dialog fechar")

button.onclick = function () {
    modal.showModal()
}
buttonClose.onclick = function () {
    modal.close()
}